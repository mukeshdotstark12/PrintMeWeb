SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OM_ABVariantData](
	[ABVariantID] [int] IDENTITY(1,1) NOT NULL,
	[ABVariantDisplayName] [nvarchar](100) NOT NULL,
	[ABVariantGUID] [uniqueidentifier] NOT NULL,
	[ABVariantTestID] [int] NOT NULL,
	[ABVariantIsOriginal] [bit] NOT NULL,
 CONSTRAINT [PK_OM_ABVariantData] PRIMARY KEY CLUSTERED 
(
	[ABVariantID] ASC
)
)

GO
CREATE NONCLUSTERED INDEX [IX_OM_ABVariantData_ABVariantTestID_ABVariantGUID] ON [dbo].[OM_ABVariantData]
(
	[ABVariantTestID] ASC,
	[ABVariantGUID] ASC
)
GO
ALTER TABLE [dbo].[OM_ABVariantData] ADD  CONSTRAINT [DEFAULT_OM_ABVariantData_ABVariantDisplayName]  DEFAULT (N'') FOR [ABVariantDisplayName]
GO
ALTER TABLE [dbo].[OM_ABVariantData] ADD  CONSTRAINT [DEFAULT_OM_ABVariantData_ABVariantGUID]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [ABVariantGUID]
GO
ALTER TABLE [dbo].[OM_ABVariantData] ADD  CONSTRAINT [DEFAULT_OM_ABVariantData_ABVariantTestID]  DEFAULT ((0)) FOR [ABVariantTestID]
GO
ALTER TABLE [dbo].[OM_ABVariantData] ADD  CONSTRAINT [DEFAULT_OM_ABVariantData_ABVariantIsOriginal]  DEFAULT ((0)) FOR [ABVariantIsOriginal]
GO
ALTER TABLE [dbo].[OM_ABVariantData]  WITH CHECK ADD  CONSTRAINT [FK_OM_ABVariantData_ABVariantTestID_OM_ABTest] FOREIGN KEY([ABVariantTestID])
REFERENCES [dbo].[OM_ABTest] ([ABTestID])
GO
ALTER TABLE [dbo].[OM_ABVariantData] CHECK CONSTRAINT [FK_OM_ABVariantData_ABVariantTestID_OM_ABTest]
GO
