CREATE TYPE [dbo].[Type_Analytics_CampaignConversionHitsTable] AS TABLE(
	[Hits] [int] NOT NULL,
	[CampaignConversionID] [int] NOT NULL,
	[ActivityUTMSource] [nvarchar](200) NOT NULL,
	[ActivityUTMContent] [nvarchar](200) NULL
)
GO
